#!/bin/sh
cd doc_root
php -f full_path